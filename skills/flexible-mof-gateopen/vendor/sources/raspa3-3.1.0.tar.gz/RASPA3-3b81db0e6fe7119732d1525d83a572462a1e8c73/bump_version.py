import re
import sys


def bump_version(file_path, pattern, replacement):
    with open(file_path, "r") as file:
        content = file.read()

    new_content, count = re.subn(pattern, replacement, content, flags=re.MULTILINE)

    if count == 0:
        raise ValueError(f"Version pattern not found in {file_path}")
    if file_path == "CMakeLists.txt" and count != 1:
        raise ValueError(f"Expected exactly one project VERSION match in {file_path}, found {count}")

    with open(file_path, "w") as file:
        file.write(new_content)


def read_current_version(file_path, pattern):
    with open(file_path, "r") as file:
        content = file.read()

    match = re.search(pattern, content, flags=re.MULTILINE)
    if match:
        return match.group(0)
    raise ValueError(f"Version pattern not found in {file_path}")


def increment_version(current_version, part):
    major, minor, patch = map(int, re.findall(r"\d+", current_version))
    if part == "major":
        major += 1
        minor = 0
        patch = 0
    elif part == "minor":
        minor += 1
        patch = 0
    elif part == "patch":
        patch += 1
    else:
        raise ValueError("Invalid part to increment. Choose 'major', 'minor', or 'patch'.")
    return f"{major}.{minor}.{patch}"


def main(new_version_or_part):
    pyproject_file = "pyproject.toml"
    cmake_file = "CMakeLists.txt"
    pkgbuild_arm_file = "packaging/PKGBUILD-arm64"
    pkgbuild_core_file = "packaging/PKGBUILD-core-avx2"
    pkgbuild_skyl_file = "packaging/PKGBUILD-skylake-avx512"
    makefilemanual_file = "src/makefile-manual"
    infoplist_file = "packaging/Info.plist"
    doxy_file_raspa = "docs/Doxyfile_raspa"
    doxy_file_raspalib = "docs/Doxyfile_raspalib"
    raspalib_version_file = "raspa/raspalib/version.py"

    pyproject_pattern = r'version\s*=\s*"\d+\.\d+\.\d+"'
    cmake_pattern = r"(^[ \t]*VERSION[ \t]+)\d+\.\d+\.\d+([ \t]*$)"
    pkgbuild_pattern = r"pkgver=\d+\.\d+\.\d+"
    makefilemanual_pattern = r"VERSION=\d+\.\d+\.\d+"
    infoplist_pattern = r"<string>\d+\.\d+\.\d+</string>"
    doxyfile_pattern = r"PROJECT_NUMBER\s*=\s*\d+\.\d+\.\d+"
    file_raspalib_pattern = r'__version__\s*=\s*"\d+\.\d+\.\d+"'

    current_version_match = re.search(r'"\d+\.\d+\.\d+"', read_current_version(pyproject_file, pyproject_pattern))
    if not current_version_match:
        raise ValueError("Current version not found in pyproject.toml")
    current_version = current_version_match.group(0).strip('"')

    if new_version_or_part in ["major", "minor", "patch"]:
        new_version = increment_version(current_version, new_version_or_part)
    else:
        new_version = new_version_or_part

    new_pyproject_version = f'version = "{new_version}"'
    new_cmake_version = rf"\g<1>{new_version}\g<2>"
    new_pkgbuild_version = f"pkgver={new_version}"
    new_makefilemanual_version = f"VERSION={new_version}"
    new_infoplist_version = f"<string>{new_version}</string>"
    new_doxyfile_version = f"PROJECT_NUMBER         = {new_version}"
    new_pyproject_version = f'version = "{new_version}"'
    new_file_raspalib_version = f'__version__ = "{new_version}"'

    bump_version(pyproject_file, pyproject_pattern, new_pyproject_version)
    bump_version(cmake_file, cmake_pattern, new_cmake_version)
    bump_version(pkgbuild_arm_file, pkgbuild_pattern, new_pkgbuild_version)
    bump_version(pkgbuild_core_file, pkgbuild_pattern, new_pkgbuild_version)
    bump_version(pkgbuild_skyl_file, pkgbuild_pattern, new_pkgbuild_version)
    bump_version(makefilemanual_file, makefilemanual_pattern, new_makefilemanual_version)
    bump_version(infoplist_file, infoplist_pattern, new_infoplist_version)
    bump_version(doxy_file_raspa, doxyfile_pattern, new_doxyfile_version)
    bump_version(doxy_file_raspalib, doxyfile_pattern, new_doxyfile_version)
    bump_version(raspalib_version_file, file_raspalib_pattern, new_file_raspalib_version)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python bump_version.py <new_version_or_part>")
    elif (sys.argv[1] not in ["major", "minor", "patch"]) and (not bool(re.match(r"^\d+\.\d+\.\d+$", sys.argv[1]))):
        print("Usage: python bump_version.py <new_version_or_part>")
    else:
        main(sys.argv[1])
