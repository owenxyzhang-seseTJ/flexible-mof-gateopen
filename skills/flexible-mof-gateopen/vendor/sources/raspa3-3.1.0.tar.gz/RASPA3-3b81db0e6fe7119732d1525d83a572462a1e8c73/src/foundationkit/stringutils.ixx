module;

export module stringutils;

import std;
import std.compat;

export inline std::string simplified(std::string a) { return a; };

export inline std::string toLower(const std::string &a)
{
  std::string data = a;
  std::transform(data.begin(), data.end(), data.begin(),
    [](unsigned char c){ return std::tolower(c); });
  return data;
}



export inline bool caseInSensStringCompare(const std::string& lhs, const std::string& rhs)
{
  return lhs.size() == rhs.size() && std::equal(lhs.begin(), lhs.end(), rhs.begin(),
                                                [](auto a, auto b) { return std::tolower(a) == std::tolower(b); });
}

export struct caseInsensitiveComparator
{
  struct nocase_compare
  {
    bool operator()(const unsigned char& c1, const unsigned char& c2) const { return tolower(c1) < tolower(c2); }
  };
  bool operator()(const std::string& lhs, const std::string& rhs) const
  {
    return std::lexicographical_compare(lhs.begin(), lhs.end(), rhs.begin(), rhs.end(), nocase_compare());
  }
};

export inline bool startsWith(const std::string& str, const std::string& prefix)
{
  return str.size() >= prefix.size() && str.substr(0, prefix.size()) == prefix;
}

export inline std::string trim(const std::string& s)
{
  auto start = s.begin();
  while (start != s.end() && std::isspace(*start))
  {
    start++;
  }

  auto end = s.end();
  do
  {
    end--;
  } while (std::distance(start, end) > 0 && std::isspace(*end));

  return std::string(start, end + 1);
}

export inline std::string addExtension(const std::string& fileName, const std::string& extension)
{
  if (fileName.length() >= extension.length() &&
      fileName.compare(fileName.length() - extension.length(), extension.length(), extension) == 0)
  {
    return fileName;
  }
  else
  {
    return fileName + extension;
  }
}

export std::string readFileContent(const std::string &fileName, const std::string &extension)
{
  std::string file_name_string = addExtension(fileName, extension);

  std::filesystem::path path = std::filesystem::path(file_name_string);
  if (!std::filesystem::exists(path))
  {
    const char* env_p = std::getenv("RASPA_DIR");
    path = std::filesystem::path(env_p) / file_name_string;
  }

  if (!std::filesystem::exists(path))
  {
    throw std::runtime_error(std::format("File '{}' not found\n", file_name_string));
  }

  std::ifstream t(path);
  std::string file_content((std::istreambuf_iterator<char>(t)), std::istreambuf_iterator<char>());

  return file_content;
}

