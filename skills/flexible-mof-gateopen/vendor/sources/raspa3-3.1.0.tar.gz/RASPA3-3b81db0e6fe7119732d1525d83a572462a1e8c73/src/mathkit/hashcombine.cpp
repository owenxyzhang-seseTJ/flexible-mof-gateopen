module;

module hashcombine;
