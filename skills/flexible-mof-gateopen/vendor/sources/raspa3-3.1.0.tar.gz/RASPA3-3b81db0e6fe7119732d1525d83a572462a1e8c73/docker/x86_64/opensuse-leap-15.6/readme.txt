docker build . -t ghcr.io/iraspa/opensuse-leap-15.6-x86_64-llvm-22:latest
